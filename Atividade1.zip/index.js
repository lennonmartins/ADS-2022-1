
function tabuada(numero) {
  console.log ("TABUADA DO " + numero);
    for (let i = 1; i <= 10; i++) {
        console.log(i + " x " + numero  + " = " + (numero * i));
    }
    console.log("\n");
    return;

}
tabuada (3);
tabuada (5);
tabuada (7);